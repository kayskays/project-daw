/**
 * Format a date string 
 * @param dateString - ISO date string
 * @param showTime - Whether to show time
 * @returns Formatted date string
 */
export const formatDate = (dateString: string, showTime: boolean = false): string => {
  const date = new Date(dateString);
  
  const options: Intl.DateTimeFormatOptions = {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
    ...(showTime && { hour: '2-digit', minute: '2-digit' })
  };
  
  return date.toLocaleDateString('en-US', options);
};