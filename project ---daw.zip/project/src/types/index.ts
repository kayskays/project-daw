export interface Article {
  id: string;
  title: string;
  summary: string;
  content: string;
  image: string;
  category: Category;
  author: string;
  publishedDate: string;
  viewCount: number;
  likes: number;
  dislikes: number;
  comments: Comment[];
}

export interface Comment {
  id: string;
  author: string;
  content: string;
  date: string;
}

export type Category = 'politics' | 'sports' | 'culture' | 'science' | 'world';

export interface UserProfile {
  viewedArticles: string[];
  likedArticles: string[];
  dislikedArticles: string[];
}