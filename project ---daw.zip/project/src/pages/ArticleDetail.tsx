import { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { getArticleById, getTrendingArticles } from '../data/newsData';
import { useUser } from '../context/UserContext';
import CommentSection from '../components/ui/CommentSection';
import LikeDislikeButtons from '../components/ui/LikeDislikeButtons';
import TrendingSidebar from '../components/ui/TrendingSidebar';
import { Article, Comment } from '../types';
import { formatDate } from '../utils/helpers';
import { Share2, Eye, ArrowLeft } from 'lucide-react';

export default function ArticleDetail() {
  const { id } = useParams<{ id: string }>();
  const [article, setArticle] = useState<Article | null>(null);
  const [loading, setLoading] = useState(true);
  const [trendingArticles, setTrendingArticles] = useState(getTrendingArticles(4));
  const { viewArticle, likeArticle, dislikeArticle } = useUser();

  useEffect(() => {
    if (id) {
      setLoading(true);
      const foundArticle = getArticleById(id);
      
      if (foundArticle) {
        // Update views count
        foundArticle.viewCount += 1;
        setArticle(foundArticle);
        
        // Record view in user context
        viewArticle(id);
        
        // Update page title
        document.title = `${foundArticle.title} | WN`;
      }
      
      setLoading(false);
    }
  }, [id, viewArticle]);

  const handleLike = () => {
    if (article) {
      // Check if already liked to toggle
      const isLiked = useUser().hasLiked(article.id);
      if (isLiked) {
        article.likes -= 1;
      } else {
        article.likes += 1;
        // If was disliked, also reduce dislike count
        if (useUser().hasDisliked(article.id)) {
          article.dislikes -= 1;
        }
      }
      
      setArticle({ ...article });
      likeArticle(article.id);
    }
  };

  const handleDislike = () => {
    if (article) {
      // Check if already disliked to toggle
      const isDisliked = useUser().hasDisliked(article.id);
      if (isDisliked) {
        article.dislikes -= 1;
      } else {
        article.dislikes += 1;
        // If was liked, also reduce like count
        if (useUser().hasLiked(article.id)) {
          article.likes -= 1;
        }
      }
      
      setArticle({ ...article });
      dislikeArticle(article.id);
    }
  };

  const handleAddComment = (comment: Comment) => {
    if (article) {
      article.comments = [comment, ...article.comments];
      setArticle({ ...article });
    }
  };

  if (loading) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="animate-pulse">
          <div className="h-8 bg-gray-200 dark:bg-gray-700 max-w-3xl mb-6 rounded"></div>
          <div className="aspect-[21/9] bg-gray-200 dark:bg-gray-700 mb-6 rounded"></div>
          <div className="space-y-3">
            <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded"></div>
            <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded"></div>
            <div className="h-4 bg-gray-200 dark:bg-gray-700 max-w-[90%] rounded"></div>
          </div>
        </div>
      </div>
    );
  }

  if (!article) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 text-center">
        <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">Article not found</h2>
        <p className="text-gray-600 dark:text-gray-400 mb-6">Sorry, we couldn't find the article you're looking for.</p>
        <Link 
          to="/" 
          className="inline-flex items-center px-4 py-2 border border-transparent text-base font-medium rounded-md shadow-sm text-white bg-blue-700 hover:bg-blue-800"
        >
          <ArrowLeft size={16} className="mr-2" /> Return to home
        </Link>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="flex flex-col lg:flex-row gap-8">
        <article className="w-full lg:w-2/3">
          {/* Back link */}
          <Link 
            to="/" 
            className="inline-flex items-center text-sm text-gray-600 dark:text-gray-400 hover:text-blue-700 dark:hover:text-blue-400 mb-6"
          >
            <ArrowLeft size={16} className="mr-1" /> Back to home
          </Link>
          
          {/* Article category */}
          <Link 
            to={`/category/${article.category}`}
            className={`inline-block px-3 py-1 mb-4 text-xs font-semibold rounded-full
              ${article.category === 'politics' ? 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-100' :
                article.category === 'sports' ? 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-100' :
                article.category === 'culture' ? 'bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-100' :
                article.category === 'science' ? 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-100' :
                'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-100'
              }`}
          >
            {article.category.charAt(0).toUpperCase() + article.category.slice(1)}
          </Link>
          
          {/* Article title */}
          <h1 className="text-3xl md:text-4xl font-bold text-gray-900 dark:text-white mb-6">
            {article.title}
          </h1>
          
          {/* Article meta */}
          <div className="flex flex-wrap items-center text-sm text-gray-600 dark:text-gray-400 mb-6 gap-y-2">
            <span className="mr-3">By <span className="font-medium text-gray-900 dark:text-white">{article.author}</span></span>
            <span className="mr-3">|</span>
            <span className="mr-3">{formatDate(article.publishedDate)}</span>
            <span className="mr-3">|</span>
            <div className="flex items-center">
              <Eye size={16} className="mr-1" />
              <span>{article.viewCount.toLocaleString()} views</span>
            </div>
          </div>
          
          {/* Featured image */}
          <div className="mb-8 rounded-lg overflow-hidden">
            <img
              src={article.image}
              alt={article.title}
              className="w-full h-auto object-cover"
            />
          </div>
          
          {/* Article engagement */}
          <div className="flex flex-wrap justify-between items-center mb-8 gap-y-4">
            <LikeDislikeButtons
              articleId={article.id}
              likes={article.likes}
              dislikes={article.dislikes}
              onLike={handleLike}
              onDislike={handleDislike}
            />
            
            <button className="flex items-center space-x-2 px-3 py-1 rounded-full bg-gray-100 dark:bg-gray-800 hover:bg-gray-200 dark:hover:bg-gray-700 text-gray-700 dark:text-gray-300 transition-colors">
              <Share2 size={18} />
              <span>Share</span>
            </button>
          </div>
          
          {/* Article content */}
          <div className="prose prose-lg max-w-none dark:prose-invert mb-12">
            {article.content.split('\n\n').map((paragraph, index) => (
              <p key={index} className="text-gray-800 dark:text-gray-200 mb-6">
                {paragraph}
              </p>
            ))}
          </div>
          
          {/* Comments section */}
          <CommentSection 
            comments={article.comments} 
            onAddComment={handleAddComment} 
          />
        </article>
        
        <aside className="w-full lg:w-1/3">
          <div className="sticky top-24">
            <TrendingSidebar articles={trendingArticles.filter(a => a.id !== article.id)} />
            
            {/* Related articles */}
            <div className="mt-8 bg-white dark:bg-gray-800 rounded-lg shadow-md p-6">
              <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-6">More from {article.category}</h3>
              <div className="space-y-4">
                {getTrendingArticles()
                  .filter(a => a.category === article.category && a.id !== article.id)
                  .slice(0, 3)
                  .map(relatedArticle => (
                    <Link 
                      key={relatedArticle.id} 
                      to={`/article/${relatedArticle.id}`}
                      className="flex group"
                    >
                      <div className="flex-shrink-0 w-20 h-20 bg-gray-100 dark:bg-gray-700 rounded overflow-hidden mr-4">
                        <img
                          src={relatedArticle.image}
                          alt={relatedArticle.title}
                          className="w-full h-full object-cover"
                        />
                      </div>
                      <div>
                        <h4 className="text-sm font-medium text-gray-900 dark:text-white group-hover:text-blue-700 dark:group-hover:text-blue-400">
                          {relatedArticle.title}
                        </h4>
                        <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
                          {formatDate(relatedArticle.publishedDate)}
                        </p>
                      </div>
                    </Link>
                  ))
                }
              </div>
            </div>
          </div>
        </aside>
      </div>
    </div>
  );
}