import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { getRecentArticles, getTrendingArticles, getArticlesByCategory } from '../data/newsData';
import ArticleCard from '../components/ui/ArticleCard';
import TrendingSidebar from '../components/ui/TrendingSidebar';
import { ChevronRight } from 'lucide-react';

export default function Home() {
  const [featuredArticles, setFeaturedArticles] = useState(getRecentArticles(1));
  const [trendingArticles, setTrendingArticles] = useState(getTrendingArticles(5));
  const [politicsArticles, setPoliticsArticles] = useState(getArticlesByCategory('politics').slice(0, 4));
  const [sportsArticles, setSportsArticles] = useState(getArticlesByCategory('sports').slice(0, 3));
  const [cultureArticles, setCultureArticles] = useState(getArticlesByCategory('culture').slice(0, 3));

  // Set page title
  useEffect(() => {
    document.title = 'WN - World News';
  }, []);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Hero section with featured article */}
      <section className="mb-12">
        {featuredArticles.map(article => (
          <Link 
            key={article.id} 
            to={`/article/${article.id}`}
            className="block group"
          >
            <div className="relative rounded-xl overflow-hidden aspect-[21/9] bg-gray-100 dark:bg-gray-800">
              <img 
                src={article.image}
                alt={article.title}
                className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/30 to-transparent flex flex-col justify-end p-6">
                <span className={`inline-block px-3 py-1 mb-4 text-xs font-semibold rounded-full w-fit
                  ${article.category === 'politics' ? 'bg-red-600 text-white' :
                    article.category === 'sports' ? 'bg-green-600 text-white' :
                    article.category === 'culture' ? 'bg-purple-600 text-white' :
                    article.category === 'science' ? 'bg-blue-600 text-white' :
                    'bg-yellow-600 text-white'
                  }`}
                >
                  {article.category.charAt(0).toUpperCase() + article.category.slice(1)}
                </span>
                <h2 className="text-2xl md:text-4xl font-bold text-white mb-4 group-hover:text-blue-300 transition-colors">
                  {article.title}
                </h2>
                <p className="text-gray-200 text-sm md:text-base max-w-3xl mb-2">
                  {article.summary}
                </p>
                <div className="flex items-center text-gray-300 text-sm">
                  <span>{article.author}</span>
                  <span className="mx-2">•</span>
                  <span>{new Date(article.publishedDate).toLocaleDateString('en-US', {
                    year: 'numeric', 
                    month: 'long', 
                    day: 'numeric'
                  })}</span>
                </div>
              </div>
            </div>
          </Link>
        ))}
      </section>

      <div className="flex flex-col lg:flex-row gap-8">
        <div className="w-full lg:w-2/3">
          {/* Featured Politics Section */}
          <section className="mb-12">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-2xl font-bold text-gray-900 dark:text-white">
                <span className="mr-2">🏛</span>Featured Politics
              </h2>
              <Link 
                to="/category/politics" 
                className="text-blue-700 dark:text-blue-400 flex items-center hover:underline text-sm font-medium"
              >
                View all <ChevronRight size={16} />
              </Link>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {politicsArticles.map((article, index) => (
                <ArticleCard 
                  key={article.id} 
                  article={article} 
                  featured={index === 0 && true}
                />
              ))}
            </div>
          </section>

          {/* Sports Section */}
          <section className="mb-12">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-2xl font-bold text-gray-900 dark:text-white">
                <span className="mr-2">⚽</span>Sports
              </h2>
              <Link 
                to="/category/sports" 
                className="text-blue-700 dark:text-blue-400 flex items-center hover:underline text-sm font-medium"
              >
                View all <ChevronRight size={16} />
              </Link>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {sportsArticles.map((article) => (
                <ArticleCard 
                  key={article.id} 
                  article={article}
                />
              ))}
            </div>
          </section>

          {/* Culture Section */}
          <section className="mb-12">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-2xl font-bold text-gray-900 dark:text-white">
                <span className="mr-2">🎭</span>Culture
              </h2>
              <Link 
                to="/category/culture" 
                className="text-blue-700 dark:text-blue-400 flex items-center hover:underline text-sm font-medium"
              >
                View all <ChevronRight size={16} />
              </Link>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {cultureArticles.map((article) => (
                <ArticleCard 
                  key={article.id} 
                  article={article}
                />
              ))}
            </div>
          </section>
        </div>

        <div className="w-full lg:w-1/3">
          <div className="sticky top-24">
            <TrendingSidebar articles={trendingArticles} />
            
            {/* Newsletter Signup */}
            <div className="mt-8 bg-gradient-to-br from-blue-700 to-blue-900 rounded-lg shadow-md p-6 text-white">
              <h3 className="text-xl font-bold mb-4">Stay Updated</h3>
              <p className="mb-4 text-blue-100">Get the latest news delivered straight to your inbox.</p>
              <form className="space-y-4">
                <div>
                  <label htmlFor="email" className="sr-only">Email address</label>
                  <input
                    id="email"
                    name="email"
                    type="email"
                    required
                    className="w-full px-4 py-2 border border-blue-600 rounded-md bg-blue-800 text-white placeholder-blue-300 focus:ring-blue-500 focus:border-blue-500"
                    placeholder="Your email address"
                  />
                </div>
                <button
                  type="submit"
                  className="w-full bg-white text-blue-900 px-4 py-2 rounded-md font-medium hover:bg-blue-50 transition-colors duration-200"
                >
                  Subscribe
                </button>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}