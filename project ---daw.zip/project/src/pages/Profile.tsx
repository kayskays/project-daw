import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { useUser } from '../context/UserContext';
import { getArticleById } from '../data/newsData';
import { Article } from '../types';
import { formatDate } from '../utils/helpers';
import { Eye, ThumbsUp, ThumbsDown, History, User as UserIcon, Clock } from 'lucide-react';

export default function Profile() {
  const { userProfile } = useUser();
  const [viewedArticles, setViewedArticles] = useState<Article[]>([]);
  const [likedArticles, setLikedArticles] = useState<Article[]>([]);
  const [dislikedArticles, setDislikedArticles] = useState<Article[]>([]);

  useEffect(() => {
    // Set page title
    document.title = 'Your Profile | WN';
    
    // Get article details for viewed, liked and disliked articles
    const viewed = userProfile.viewedArticles
      .map(id => getArticleById(id))
      .filter(article => article !== undefined) as Article[];
      
    const liked = userProfile.likedArticles
      .map(id => getArticleById(id))
      .filter(article => article !== undefined) as Article[];
      
    const disliked = userProfile.dislikedArticles
      .map(id => getArticleById(id))
      .filter(article => article !== undefined) as Article[];
      
    setViewedArticles(viewed);
    setLikedArticles(liked);
    setDislikedArticles(disliked);
  }, [userProfile]);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-12 text-center">
        <div className="inline-flex items-center justify-center w-20 h-20 bg-blue-100 dark:bg-blue-900 rounded-full mb-4">
          <UserIcon size={32} className="text-blue-700 dark:text-blue-400" />
        </div>
        <h1 className="text-3xl font-bold text-gray-900 dark:text-white">Your Profile</h1>
        <p className="text-gray-600 dark:text-gray-400 mt-2">
          Track your reading history and interactions
        </p>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-12 gap-8">
        {/* Activity summary */}
        <div className="md:col-span-4 space-y-4">
          <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6">
            <h2 className="text-xl font-bold text-gray-900 dark:text-white mb-6">Activity Summary</h2>
            <div className="space-y-4">
              <div className="flex items-center">
                <div className="flex-shrink-0 flex items-center justify-center w-12 h-12 bg-blue-100 dark:bg-blue-900 rounded-full">
                  <History size={20} className="text-blue-700 dark:text-blue-400" />
                </div>
                <div className="ml-4">
                  <p className="text-sm font-medium text-gray-900 dark:text-white">Articles Read</p>
                  <p className="text-2xl font-bold text-gray-900 dark:text-white">
                    {viewedArticles.length}
                  </p>
                </div>
              </div>
              
              <div className="flex items-center">
                <div className="flex-shrink-0 flex items-center justify-center w-12 h-12 bg-green-100 dark:bg-green-900 rounded-full">
                  <ThumbsUp size={20} className="text-green-700 dark:text-green-400" />
                </div>
                <div className="ml-4">
                  <p className="text-sm font-medium text-gray-900 dark:text-white">Liked Articles</p>
                  <p className="text-2xl font-bold text-gray-900 dark:text-white">
                    {likedArticles.length}
                  </p>
                </div>
              </div>
              
              <div className="flex items-center">
                <div className="flex-shrink-0 flex items-center justify-center w-12 h-12 bg-red-100 dark:bg-red-900 rounded-full">
                  <ThumbsDown size={20} className="text-red-700 dark:text-red-400" />
                </div>
                <div className="ml-4">
                  <p className="text-sm font-medium text-gray-900 dark:text-white">Disliked Articles</p>
                  <p className="text-2xl font-bold text-gray-900 dark:text-white">
                    {dislikedArticles.length}
                  </p>
                </div>
              </div>
            </div>
          </div>
          
          <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6">
            <h2 className="text-xl font-bold text-gray-900 dark:text-white mb-6">Reading Preferences</h2>
            {viewedArticles.length > 0 ? (
              <div className="space-y-4">
                {/* Calculate category percentages */}
                {(['politics', 'sports', 'culture', 'science', 'world'] as const).map(category => {
                  const count = viewedArticles.filter(article => article.category === category).length;
                  const percentage = viewedArticles.length > 0 
                    ? Math.round((count / viewedArticles.length) * 100) 
                    : 0;
                  
                  let bgColorClass = '';
                  switch(category) {
                    case 'politics': bgColorClass = 'bg-red-500'; break;
                    case 'sports': bgColorClass = 'bg-green-500'; break;
                    case 'culture': bgColorClass = 'bg-purple-500'; break;
                    case 'science': bgColorClass = 'bg-blue-500'; break;
                    case 'world': bgColorClass = 'bg-yellow-500'; break;
                  }
                  
                  return (
                    <div key={category}>
                      <div className="flex justify-between items-center mb-1">
                        <p className="text-sm font-medium text-gray-700 dark:text-gray-300 capitalize">
                          {category}
                        </p>
                        <p className="text-sm font-medium text-gray-700 dark:text-gray-300">
                          {percentage}%
                        </p>
                      </div>
                      <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2.5">
                        <div 
                          className={`h-2.5 rounded-full ${bgColorClass}`} 
                          style={{ width: `${percentage}%` }}
                        ></div>
                      </div>
                    </div>
                  );
                })}
              </div>
            ) : (
              <p className="text-gray-600 dark:text-gray-400 text-center py-4">
                Start reading articles to see your preferences
              </p>
            )}
          </div>
        </div>
        
        {/* Reading history */}
        <div className="md:col-span-8">
          <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6 mb-6">
            <h2 className="text-xl font-bold text-gray-900 dark:text-white mb-6">
              <History size={20} className="inline-block mr-2" />
              Your Reading History
            </h2>
            
            {viewedArticles.length > 0 ? (
              <div className="space-y-6">
                {viewedArticles.map((article, index) => (
                  <div key={article.id} className="relative pl-8 pb-8">
                    {/* Timeline connector */}
                    {index !== viewedArticles.length - 1 && (
                      <div className="absolute top-0 left-3 h-full w-0.5 bg-gray-200 dark:bg-gray-700"></div>
                    )}
                    
                    {/* Timeline dot */}
                    <div className="absolute top-1 left-0 h-6 w-6 rounded-full bg-blue-100 dark:bg-blue-900 flex items-center justify-center">
                      <Clock size={14} className="text-blue-700 dark:text-blue-400" />
                    </div>
                    
                    <Link to={`/article/${article.id}`} className="block group">
                      <div className="flex flex-col sm:flex-row sm:items-center">
                        <div className="sm:flex-shrink-0 sm:w-32 sm:h-20 rounded overflow-hidden mb-2 sm:mb-0 sm:mr-4">
                          <img
                            src={article.image}
                            alt={article.title}
                            className="w-full h-full object-cover"
                          />
                        </div>
                        <div>
                          <h3 className="text-md font-semibold text-gray-900 dark:text-white group-hover:text-blue-700 dark:group-hover:text-blue-400">
                            {article.title}
                          </h3>
                          <div className="flex flex-wrap items-center text-xs text-gray-500 dark:text-gray-400 mt-1 gap-y-1">
                            <span className={`inline-block px-2 py-0.5 mr-2 rounded
                              ${article.category === 'politics' ? 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-100' :
                                article.category === 'sports' ? 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-100' :
                                article.category === 'culture' ? 'bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-100' :
                                article.category === 'science' ? 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-100' :
                                'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-100'
                              }`}
                            >
                              {article.category}
                            </span>
                            <span className="flex items-center mr-2">
                              <Eye size={12} className="mr-1" />
                              {article.viewCount.toLocaleString()}
                            </span>
                            <span>{formatDate(article.publishedDate)}</span>
                          </div>
                        </div>
                      </div>
                    </Link>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-8">
                <div className="inline-flex items-center justify-center w-16 h-16 bg-gray-100 dark:bg-gray-700 rounded-full mb-4">
                  <History size={24} className="text-gray-500 dark:text-gray-400" />
                </div>
                <p className="text-gray-600 dark:text-gray-400 mb-4">
                  You haven't read any articles yet
                </p>
                <Link 
                  to="/" 
                  className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-blue-700 hover:bg-blue-800"
                >
                  Browse articles
                </Link>
              </div>
            )}
          </div>
          
          {likedArticles.length > 0 && (
            <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6">
              <h2 className="text-xl font-bold text-gray-900 dark:text-white mb-6">
                <ThumbsUp size={20} className="inline-block mr-2" />
                Articles You Liked
              </h2>
              
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {likedArticles.map(article => (
                  <Link 
                    key={article.id} 
                    to={`/article/${article.id}`}
                    className="flex group p-3 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700"
                  >
                    <div className="flex-shrink-0 w-16 h-16 bg-gray-100 dark:bg-gray-700 rounded overflow-hidden mr-3">
                      <img
                        src={article.image}
                        alt={article.title}
                        className="w-full h-full object-cover"
                      />
                    </div>
                    <div>
                      <h3 className="text-sm font-medium text-gray-900 dark:text-white group-hover:text-blue-700 dark:group-hover:text-blue-400 line-clamp-2">
                        {article.title}
                      </h3>
                      <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
                        {formatDate(article.publishedDate)}
                      </p>
                    </div>
                  </Link>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}