import { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import { getArticlesByCategory, getTrendingArticles } from '../data/newsData';
import ArticleCard from '../components/ui/ArticleCard';
import TrendingSidebar from '../components/ui/TrendingSidebar';
import CategoryTabs from '../components/ui/CategoryTabs';
import { Article, Category } from '../types';

export default function CategoryPage() {
  const { category } = useParams<{ category: Category }>();
  const [articles, setArticles] = useState<Article[]>([]);
  const [trendingArticles, setTrendingArticles] = useState<Article[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (category) {
      setLoading(true);
      const categoryArticles = getArticlesByCategory(category as Category);
      const trending = getTrendingArticles(4);
      
      setArticles(categoryArticles);
      setTrendingArticles(trending);
      setLoading(false);
      
      // Update page title
      const categoryName = category.charAt(0).toUpperCase() + category.slice(1);
      document.title = `${categoryName} News | WN`;
    }
  }, [category]);

  const getCategoryEmoji = (category: Category): string => {
    switch (category) {
      case 'politics': return '🏛';
      case 'sports': return '⚽';
      case 'culture': return '🎭';
      case 'science': return '🔬';
      case 'world': return '🌍';
      default: return '';
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <CategoryTabs />
      
      <div className="flex flex-col lg:flex-row gap-8">
        <div className="w-full lg:w-2/3">
          <div className="mb-8">
            <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-2">
              {getCategoryEmoji(category as Category)} {category?.charAt(0).toUpperCase() + category?.slice(1)} News
            </h1>
            <p className="text-gray-600 dark:text-gray-400">
              The latest updates and breaking news from the world of {category}
            </p>
          </div>
          
          {loading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {[1, 2, 3, 4].map((item) => (
                <div key={item} className="animate-pulse">
                  <div className="aspect-[16/9] bg-gray-200 dark:bg-gray-700 rounded-lg mb-4"></div>
                  <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded mb-2"></div>
                  <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded w-3/4"></div>
                </div>
              ))}
            </div>
          ) : articles.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {articles.map((article, index) => (
                <ArticleCard 
                  key={article.id} 
                  article={article} 
                  featured={index === 0 && true}
                />
              ))}
            </div>
          ) : (
            <div className="text-center py-12">
              <p className="text-gray-600 dark:text-gray-400">No articles found in this category.</p>
            </div>
          )}
        </div>
        
        <div className="w-full lg:w-1/3">
          <div className="sticky top-24">
            <TrendingSidebar articles={trendingArticles} />
          </div>
        </div>
      </div>
    </div>
  );
}