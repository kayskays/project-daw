import { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { UserProfile } from '../types';

interface UserContextType {
  userProfile: UserProfile;
  viewArticle: (articleId: string) => void;
  likeArticle: (articleId: string) => void;
  dislikeArticle: (articleId: string) => void;
  hasLiked: (articleId: string) => boolean;
  hasDisliked: (articleId: string) => boolean;
  hasViewed: (articleId: string) => boolean;
}

const UserContext = createContext<UserContextType | undefined>(undefined);

const defaultUserProfile: UserProfile = {
  viewedArticles: [],
  likedArticles: [],
  dislikedArticles: [],
};

export function UserProvider({ children }: { children: ReactNode }) {
  // Initialize from localStorage or use default
  const [userProfile, setUserProfile] = useState<UserProfile>(() => {
    const savedProfile = localStorage.getItem('userProfile');
    return savedProfile ? JSON.parse(savedProfile) : defaultUserProfile;
  });

  // Save to localStorage when profile changes
  useEffect(() => {
    localStorage.setItem('userProfile', JSON.stringify(userProfile));
  }, [userProfile]);

  const viewArticle = (articleId: string) => {
    setUserProfile(prev => {
      if (!prev.viewedArticles.includes(articleId)) {
        return {
          ...prev,
          viewedArticles: [articleId, ...prev.viewedArticles],
        };
      }
      return prev;
    });
  };

  const likeArticle = (articleId: string) => {
    setUserProfile(prev => {
      // If already liked, remove like
      if (prev.likedArticles.includes(articleId)) {
        return {
          ...prev,
          likedArticles: prev.likedArticles.filter(id => id !== articleId),
        };
      }
      
      // Add like and remove dislike if exists
      return {
        ...prev,
        likedArticles: [articleId, ...prev.likedArticles],
        dislikedArticles: prev.dislikedArticles.filter(id => id !== articleId),
      };
    });
  };

  const dislikeArticle = (articleId: string) => {
    setUserProfile(prev => {
      // If already disliked, remove dislike
      if (prev.dislikedArticles.includes(articleId)) {
        return {
          ...prev,
          dislikedArticles: prev.dislikedArticles.filter(id => id !== articleId),
        };
      }
      
      // Add dislike and remove like if exists
      return {
        ...prev,
        dislikedArticles: [articleId, ...prev.dislikedArticles],
        likedArticles: prev.likedArticles.filter(id => id !== articleId),
      };
    });
  };

  const hasLiked = (articleId: string): boolean => {
    return userProfile.likedArticles.includes(articleId);
  };

  const hasDisliked = (articleId: string): boolean => {
    return userProfile.dislikedArticles.includes(articleId);
  };

  const hasViewed = (articleId: string): boolean => {
    return userProfile.viewedArticles.includes(articleId);
  };

  return (
    <UserContext.Provider 
      value={{ 
        userProfile, 
        viewArticle, 
        likeArticle, 
        dislikeArticle, 
        hasLiked, 
        hasDisliked, 
        hasViewed 
      }}
    >
      {children}
    </UserContext.Provider>
  );
}

export function useUser(): UserContextType {
  const context = useContext(UserContext);
  if (context === undefined) {
    throw new Error('useUser must be used within a UserProvider');
  }
  return context;
}