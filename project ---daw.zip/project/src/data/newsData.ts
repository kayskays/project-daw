import { Article, Category } from '../types';
import { v4 as uuidv4 } from 'uuid';

// Helper function to create article
const createArticle = (
  title: string,
  summary: string,
  content: string,
  image: string,
  category: Category,
  author: string,
  publishedDate: string,
  viewCount = 0,
  likes = 0,
  dislikes = 0,
  comments = []
): Article => ({
  id: uuidv4(),
  title,
  summary,
  content,
  image,
  category,
  author,
  publishedDate,
  viewCount,
  likes,
  dislikes,
  comments,
});

// Generate mock news data
export const newsArticles: Article[] = [
  // Politics Articles (Featured Category)
  createArticle(
    'Global Summit Addresses Climate Policy Changes',
    'World leaders gather to discuss ambitious climate goals amid growing concerns.',
    `In an unprecedented gathering of global leaders, the Climate Summit 2025 has concluded with several major policy announcements. The United States and European Union have jointly pledged to reduce carbon emissions by 60% before 2035, marking a significant acceleration from previous commitments.

    "This is a turning point in our collective fight against climate change," stated UN Secretary-General in the closing ceremony. "The commitments made today will reshape global industry and energy production for decades to come."

    The summit also introduced a new $100 billion climate fund to assist developing nations in transitioning to renewable energy sources. China surprised attendees by announcing plans to peak its carbon emissions by 2027, three years earlier than previously stated.

    Environmental activists have cautiously welcomed these announcements but emphasize the need for concrete implementation plans and accountability measures.`,
    'https://images.pexels.com/photos/2990644/pexels-photo-2990644.jpeg',
    'politics',
    'Emma Johnson',
    '2025-04-12',
    1254,
    342,
    28,
    [
      {
        id: uuidv4(),
        author: 'GlobalCitizen',
        content: 'About time! We need action, not just more promises.',
        date: '2025-04-12T15:32:00',
      },
      {
        id: uuidv4(),
        author: 'EcoWatcher',
        content: 'The 60% target seems ambitious but necessary. I wonder how they plan to achieve it.',
        date: '2025-04-12T16:45:00',
      },
    ]
  ),
  createArticle(
    'Parliament Passes Controversial Digital Privacy Bill',
    'New legislation grants expanded surveillance powers while promising enhanced data protection.',
    `After months of heated debate, Parliament has passed the Digital Communications and Privacy Act with a narrow majority of 218 to 204. The legislation introduces sweeping changes to how digital communications are monitored and how personal data is protected.

    Supporters of the bill argue it provides necessary tools for national security while simultaneously strengthening individual privacy rights through stricter penalties for data breaches. Opposition leaders have criticized the legislation, claiming it creates dangerous surveillance precedents.

    "This bill strikes the right balance between security and privacy in the digital age," said the Minister of Digital Affairs. "It equips our security services with modern tools while holding data handlers to the highest standards."

    Civil liberties groups have announced plans to challenge several provisions of the bill in court, focusing particularly on the expanded powers granted to intelligence agencies to access encrypted communications.`,
    'https://images.pexels.com/photos/3183183/pexels-photo-3183183.jpeg',
    'politics',
    'Marcus Rivera',
    '2025-04-10',
    982,
    167,
    89,
    [
      {
        id: uuidv4(),
        author: 'PrivacyAdvocate',
        content: 'This is a dangerous precedent. Encryption backdoors never stay limited to "just the good guys."',
        date: '2025-04-10T19:14:00',
      },
    ]
  ),
  createArticle(
    'Presidential Candidates Face Off in First Debate',
    'Economic policy and healthcare dominate discussion as election season begins.',
    `The first presidential debate of the 2025 election cycle took place last night, with candidates focusing heavily on economic recovery plans and healthcare reform. The incumbent president defended his administration's record on job creation and pandemic management, while the challenging candidate criticized current policies on inflation and healthcare costs.

    "The American people deserve a healthcare system that doesn't bankrupt them when they get sick," stated the challenger to applause from supporters. The president countered by highlighting recent legislation that has capped insulin costs and expanded coverage.

    Political analysts noted the debate remained largely focused on policy, with fewer personal attacks than expected. Polling immediately following the debate showed viewers split on who performed better, with 48% favoring the incumbent and 46% the challenger.

    The candidates will meet again in three weeks for a debate focusing specifically on foreign policy and climate initiatives.`,
    'https://images.pexels.com/photos/8848089/pexels-photo-8848089.jpeg',
    'politics',
    'Sophia Chen',
    '2025-04-08',
    1578,
    412,
    356,
    []
  ),

  // Sports Articles
  createArticle(
    'National Team Advances to World Cup Semifinals',
    'Historic victory sets up showdown with defending champions next week.',
    `In what commentators are calling "the game of the tournament," the national team secured a place in the World Cup semifinals with a dramatic 3-2 victory yesterday. The team overcame a two-goal deficit in the second half, with the winning goal scored in the final minute of extra time.

    "This team never knows when they're beaten," said the head coach after the match. "The character shown today was exceptional, but we're not satisfied yet. We have two more games to win."

    The comeback was spearheaded by midfielder James Wilson, who scored one goal and assisted another in a player-of-the-match performance. The team will now face the defending champions in what promises to be an electric semifinal next Tuesday.

    Fan zones across the country erupted in celebration, with thousands taking to the streets in major cities to mark the historic achievement. This is the first time in 24 years that the national team has reached the World Cup semifinals.`,
    'https://images.pexels.com/photos/46798/the-ball-stadion-football-the-pitch-46798.jpeg',
    'sports',
    'Carlos Mendez',
    '2025-04-11',
    2134,
    896,
    42,
    []
  ),
  createArticle(
    'Tennis Star Claims Fifth Grand Slam Title',
    'Dominant performance in finals cements place among all-time greats.',
    `In a masterclass of skill and determination, tennis superstar Alexia Novak claimed her fifth Grand Slam title yesterday with a straight-sets victory in the finals. The win solidifies her position as the current world number one and places her among an elite group of players in the sport's history.

    "This one means the most to me," said Novak, who returned from a serious injury just eight months ago. "There were moments during rehabilitation when I wasn't sure if I'd ever compete at this level again."

    The match lasted just 74 minutes, with Novak demonstrating her full arsenal of shots and tactical acumen. Her opponent, ranked third in the world, struggled to find answers to Novak's powerful baseline game and precise serving.

    Tennis legends have praised the performance, with former champion Stefan Berg calling it "perhaps the most complete display of tennis I've seen in a Grand Slam final in decades."`,
    'https://images.pexels.com/photos/1432039/pexels-photo-1432039.jpeg',
    'sports',
    'Jackson Williams',
    '2025-04-09',
    1765,
    532,
    24,
    []
  ),

  // Culture Articles
  createArticle(
    'Acclaimed Director Announces Groundbreaking Film Project',
    'Innovative narrative structure and virtual production techniques promise to redefine cinematic storytelling.',
    `Award-winning director Eleanor Shaw has announced her next project, an ambitious film that will utilize cutting-edge virtual production technology alongside a non-linear narrative structure. The project, titled "Continuum," explores the interconnected lives of seven individuals across different time periods and continents.

    "Cinema needs to evolve both technically and narratively," Shaw explained during the announcement. "With 'Continuum,' we're attempting to create an experience that couldn't have existed even five years ago."

    The film will be shot entirely on virtual stages using technology similar to that pioneered on "The Mandalorian," but with significant advancements. Actors will perform in environments rendered in real-time, allowing for unprecedented creative flexibility.

    The project has already attracted a stellar cast, including three Academy Award winners. Production is set to begin in September with a targeted release date in late 2026.`,
    'https://images.pexels.com/photos/3062541/pexels-photo-3062541.jpeg',
    'culture',
    'Olivia Martinez',
    '2025-04-07',
    843,
    291,
    14,
    []
  ),
  createArticle(
    'Virtual Reality Art Exhibition Breaks Attendance Records',
    'Groundbreaking show blends traditional techniques with immersive technology.',
    `The Metropolitan Museum's experimental virtual reality exhibition "Perspectives" has become the most visited art show in the institution's history, with over one million virtual attendees in its first month. The exhibition allows visitors from around the world to experience the museum's masterpieces in a revolutionary way.

    Using VR headsets or standard web browsers, visitors can explore meticulously recreated gallery spaces where artwork comes alive through interactive elements. Rembrandt's self-portraits age before viewers' eyes, while Van Gogh's starry night engulfs the visitor in swirling cosmos.

    "We wanted to democratize access to great art while adding new dimensions to familiar masterpieces," explained the museum's digital director. "The response has exceeded our wildest expectations."

    Art critics have largely praised the initiative, though some traditionalists have questioned whether the interactive elements distract from appreciation of the original works. The exhibition has been extended for an additional six months due to unprecedented demand.`,
    'https://images.pexels.com/photos/2372978/pexels-photo-2372978.jpeg',
    'culture',
    'Nathan Kim',
    '2025-04-05',
    921,
    347,
    32,
    []
  ),

  // Science Articles
  createArticle(
    'Breakthrough in Quantum Computing Reaches New Milestone',
    'Researchers achieve quantum supremacy with 1,000-qubit processor capable of solving previously impossible problems.',
    `Scientists at the Quantum Research Institute have announced a significant breakthrough in quantum computing technology, successfully operating a 1,000-qubit processor that maintained quantum coherence for a record 9.2 milliseconds. This achievement represents a major step toward practical quantum computing applications.

    "This is the moment when quantum computing transitions from theoretical promise to practical tool," said Dr. Leila Patel, lead researcher on the project. "We can now tackle certain classes of problems that would take conventional supercomputers thousands of years to solve."

    The team demonstrated the processor's capabilities by simulating complex molecular interactions for potential pharmaceutical compounds—a task that has traditionally been bottlenecked by computational limitations. The simulation identified several promising candidate molecules for targeted drug development.

    Industry analysts suggest this breakthrough could accelerate advancements in materials science, cryptography, and artificial intelligence. Major technology companies have already announced plans to incorporate the new quantum architecture into their research divisions.`,
    'https://images.pexels.com/photos/373543/pexels-photo-373543.jpeg',
    'science',
    'Dr. Rajiv Kumar',
    '2025-04-06',
    1432,
    528,
    17,
    []
  ),
  createArticle(
    'Mars Mission Discovers Evidence of Ancient Microbial Life',
    'Robotic exploration reveals fossilized bacteria-like structures in Martian rock samples.',
    `The International Mars Mission has announced a potentially historic discovery: evidence suggesting ancient microbial life once existed on the red planet. The mission's advanced rover identified fossilized structures in 3.7 billion-year-old Martian rock formations that bear striking similarities to bacterial colonies found on early Earth.

    "While we cannot yet conclusively state these are fossilized life forms, the morphological and chemical evidence is compelling," stated mission director Dr. Sarah Foster at a press conference that captivated the scientific community.

    The structures were found in ancient lakebed deposits in Mars' Jezero Crater, an area specifically chosen for exploration due to its geological history of containing water. Sophisticated instruments aboard the rover detected organic compounds and specific mineral formations typically associated with biological processes.

    Samples containing the structures have been sealed and prepared for the upcoming Mars Sample Return mission, which will bring the specimens to Earth for more detailed analysis. If confirmed, this would represent the first evidence of life beyond Earth in our solar system.`,
    'https://images.pexels.com/photos/73910/mars-mars-rover-space-travel-robot-73910.jpeg',
    'science',
    'Dr. James Wilson',
    '2025-04-02',
    2541,
    967,
    23,
    []
  ),

  // World Articles
  createArticle(
    'Historic Peace Agreement Ends Decades-Long Conflict',
    'Regional powers broker comprehensive peace deal after marathon negotiations.',
    `After more than two years of intense negotiations, representatives signed a comprehensive peace agreement yesterday, officially ending a conflict that has claimed over 200,000 lives and displaced millions. The signing ceremony, attended by UN officials and diplomatic representatives from 32 countries, marks the culmination of efforts that many observers had considered impossible just months ago.

    The agreement includes provisions for disarmament, power-sharing in a transitional government, and international monitoring mechanisms. A special tribunal will be established to address human rights violations committed during the conflict.

    "This day belongs to the people who have suffered immeasurably and never lost hope," said the UN Secretary-General. "Implementation will face challenges, but the foundation for lasting peace has been laid."

    Celebrations erupted in cities and refugee camps following the announcement, though analysts caution that significant hurdles remain in the implementation phase. An international donor conference will convene next month to secure funding for reconstruction efforts estimated at $50 billion over the next decade.`,
    'https://images.pexels.com/photos/1250452/pexels-photo-1250452.jpeg',
    'world',
    'Elena Rodriguez',
    '2025-04-04',
    1876,
    745,
    31,
    []
  ),
  createArticle(
    'Global Economic Forum Predicts Major Shift in Trade Patterns',
    'Emerging markets set to dominate global commerce in coming decade according to new report.',
    `The latest World Economic Outlook report predicts a fundamental restructuring of global trade patterns over the next decade, with emerging economies projected to account for 62% of world trade by 2035. This marks a significant power shift from the current 43% share.

    "We're witnessing the most significant realignment of economic power since the industrial revolution," said Dr. Kwame Nkrumah, chief economist at the Global Economic Forum. "The implications for everything from supply chains to international relations are profound."

    The report identifies several driving factors, including demographic advantages, technological leapfrogging, and strategic infrastructure investments in emerging economies. Regional trade blocs centered around the ASEAN, African Union, and Latin American nations are expected to drive much of this growth.

    Established economic powers face significant challenges in this new landscape, with the report recommending substantial investments in innovation, education reform, and strategic international partnerships to maintain competitive positions.`,
    'https://images.pexels.com/photos/159888/pexels-photo-159888.jpeg',
    'world',
    'Thomas Anderson',
    '2025-04-01',
    1243,
    398,
    87,
    []
  ),
];

// Helper function to get articles by category
export const getArticlesByCategory = (category: Category): Article[] => {
  return newsArticles.filter(article => article.category === category);
};

// Helper function to get article by id
export const getArticleById = (id: string): Article | undefined => {
  return newsArticles.find(article => article.id === id);
};

// Helper function to get trending articles (most viewed)
export const getTrendingArticles = (limit: number = 5): Article[] => {
  return [...newsArticles].sort((a, b) => b.viewCount - a.viewCount).slice(0, limit);
};

// Helper function to get recent articles
export const getRecentArticles = (limit: number = 5): Article[] => {
  return [...newsArticles]
    .sort((a, b) => new Date(b.publishedDate).getTime() - new Date(a.publishedDate).getTime())
    .slice(0, limit);
};