import { useState } from 'react';
import { Link } from 'react-router-dom';
import { Article } from '../../types';
import { formatDate } from '../../utils/helpers';
import { Eye } from 'lucide-react';

interface ArticleCardProps {
  article: Article;
  featured?: boolean;
}

export default function ArticleCard({ article, featured = false }: ArticleCardProps) {
  const [isHovered, setIsHovered] = useState(false);

  return (
    <Link 
      to={`/article/${article.id}`}
      className={`block group ${featured ? 'col-span-2' : ''}`}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      <div className={`flex flex-col h-full overflow-hidden rounded-lg shadow-md hover:shadow-lg transition-all duration-300 bg-white dark:bg-gray-800 ${
        featured ? 'md:flex-row' : ''
      }`}>
        <div className={`relative overflow-hidden ${
          featured ? 'md:w-1/2' : 'aspect-[16/9]'
        }`}>
          <img
            src={article.image}
            alt={article.title}
            className={`w-full h-full object-cover transition-transform duration-500 ${
              isHovered ? 'scale-105' : 'scale-100'
            }`}
          />
          <div className="absolute top-0 left-0 m-3">
            <span className={`inline-block px-3 py-1 text-xs font-semibold rounded-full 
              ${article.category === 'politics' ? 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-100' :
                article.category === 'sports' ? 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-100' :
                article.category === 'culture' ? 'bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-100' :
                article.category === 'science' ? 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-100' :
                'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-100'
              }`}
            >
              {article.category.charAt(0).toUpperCase() + article.category.slice(1)}
            </span>
          </div>
        </div>
        <div className={`flex flex-col p-4 ${featured ? 'md:w-1/2' : ''}`}>
          <h3 className={`font-bold text-gray-900 dark:text-white group-hover:text-blue-700 dark:group-hover:text-blue-400 transition-colors ${
            featured ? 'text-xl md:text-2xl' : 'text-lg'
          }`}>
            {article.title}
          </h3>
          <p className="mt-2 text-sm text-gray-600 dark:text-gray-300 line-clamp-2">
            {article.summary}
          </p>
          <div className="mt-auto pt-4 flex items-center justify-between text-sm text-gray-500 dark:text-gray-400">
            <span>{formatDate(article.publishedDate)}</span>
            <div className="flex items-center">
              <Eye size={16} className="mr-1" />
              <span>{article.viewCount.toLocaleString()}</span>
            </div>
          </div>
        </div>
      </div>
    </Link>
  );
}