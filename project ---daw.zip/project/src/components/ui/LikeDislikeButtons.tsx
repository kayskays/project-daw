import { ThumbsUp, ThumbsDown } from 'lucide-react';
import { useUser } from '../../context/UserContext';

interface LikeDislikeButtonsProps {
  articleId: string;
  likes: number;
  dislikes: number;
  onLike: () => void;
  onDislike: () => void;
}

export default function LikeDislikeButtons({
  articleId,
  likes,
  dislikes,
  onLike,
  onDislike
}: LikeDislikeButtonsProps) {
  const { hasLiked, hasDisliked } = useUser();
  
  const isLiked = hasLiked(articleId);
  const isDisliked = hasDisliked(articleId);

  return (
    <div className="flex space-x-4">
      <button
        className={`flex items-center space-x-1 px-3 py-1 rounded-full transition-all ${
          isLiked 
            ? 'bg-blue-100 dark:bg-blue-900 text-blue-700 dark:text-blue-300' 
            : 'bg-gray-100 dark:bg-gray-800 text-gray-700 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-700'
        }`}
        onClick={onLike}
        aria-label={isLiked ? "Unlike" : "Like"}
      >
        <ThumbsUp size={18} className={isLiked ? 'fill-blue-700 dark:fill-blue-300' : ''} />
        <span>{likes.toLocaleString()}</span>
      </button>
      
      <button
        className={`flex items-center space-x-1 px-3 py-1 rounded-full transition-all ${
          isDisliked 
            ? 'bg-red-100 dark:bg-red-900 text-red-700 dark:text-red-300' 
            : 'bg-gray-100 dark:bg-gray-800 text-gray-700 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-700'
        }`}
        onClick={onDislike}
        aria-label={isDisliked ? "Remove dislike" : "Dislike"}
      >
        <ThumbsDown size={18} className={isDisliked ? 'fill-red-700 dark:fill-red-300' : ''} />
        <span>{dislikes.toLocaleString()}</span>
      </button>
    </div>
  );
}