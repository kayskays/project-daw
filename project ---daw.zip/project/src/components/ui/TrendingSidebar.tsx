import { Link } from 'react-router-dom';
import { Article } from '../../types';
import { TrendingUp } from 'lucide-react';

interface TrendingSidebarProps {
  articles: Article[];
}

export default function TrendingSidebar({ articles }: TrendingSidebarProps) {
  return (
    <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6">
      <div className="flex items-center mb-6">
        <TrendingUp size={20} className="text-red-600 dark:text-red-400 mr-2" />
        <h3 className="text-xl font-bold text-gray-900 dark:text-white">Trending</h3>
      </div>
      
      <div className="space-y-6">
        {articles.map((article, index) => (
          <Link key={article.id} to={`/article/${article.id}`} className="block group">
            <div className="flex items-start">
              <span className="mr-4 flex-shrink-0 text-2xl font-bold text-gray-300 dark:text-gray-600">
                {index + 1}
              </span>
              <div>
                <h4 className="text-md font-medium text-gray-900 dark:text-white group-hover:text-blue-700 dark:group-hover:text-blue-400 transition-colors">
                  {article.title}
                </h4>
                <div className="mt-1 flex items-center text-xs text-gray-500 dark:text-gray-400">
                  <span className="capitalize">{article.category}</span>
                  <span className="mx-2">•</span>
                  <span>{article.viewCount.toLocaleString()} views</span>
                </div>
              </div>
            </div>
          </Link>
        ))}
      </div>
      
      <Link 
        to="/" 
        className="mt-6 block text-sm font-medium text-blue-700 dark:text-blue-400 hover:text-blue-800 dark:hover:text-blue-300"
      >
        View all trending articles →
      </Link>
    </div>
  );
}