import { Link, useParams } from 'react-router-dom';
import { Category } from '../../types';

const categories: { name: string; value: Category; emoji: string }[] = [
  { name: 'Politics', value: 'politics', emoji: '🏛' },
  { name: 'Sports', value: 'sports', emoji: '⚽' },
  { name: 'Culture', value: 'culture', emoji: '🎭' },
  { name: 'Science', value: 'science', emoji: '🔬' },
  { name: 'World', value: 'world', emoji: '🌍' },
];

export default function CategoryTabs() {
  const { category } = useParams<{ category: Category }>();
  
  return (
    <div className="mb-8">
      <div className="border-b border-gray-200 dark:border-gray-700">
        <nav className="-mb-px flex space-x-8 overflow-x-auto">
          {categories.map((cat) => (
            <Link
              key={cat.value}
              to={`/category/${cat.value}`}
              className={`
                whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm
                ${category === cat.value
                  ? 'border-blue-700 dark:border-blue-500 text-blue-700 dark:text-blue-500'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300 dark:text-gray-400 dark:hover:text-gray-300 dark:hover:border-gray-600'
                }
              `}
              aria-current={category === cat.value ? 'page' : undefined}
            >
              <span className="mr-2">{cat.emoji}</span>
              {cat.name}
            </Link>
          ))}
        </nav>
      </div>
    </div>
  );
}